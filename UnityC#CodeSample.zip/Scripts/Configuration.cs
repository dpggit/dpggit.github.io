﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using NUnit.Framework;


namespace GameControls
{
    [System.Serializable]
    public class JsonConfig
    {
        public int cardScore;
        public int multiplier;
        public int livesCount;
        public int powerupsCount;
        public int[] cardIds;
    }

    public class Configuration : MonoBehaviour
    {
        public ConfigurationScriptableObject ConfigurationScriptableObject;

        public static Configuration Singleton;

        private JsonConfig ConfigurationValues;

        private void Awake()
        {
            if (Singleton != null) Destroy(gameObject);
            else Singleton = this;
        }

        void Start()
        {
            DontDestroyOnLoad(gameObject);
            StartCoroutine(GetConfiguration());
        }

        public IEnumerator GetConfiguration()
        {
            UnityWebRequest www = UnityWebRequest.Get("http://localhost:3000/configuration/1");
            www.SetRequestHeader("Accept", "application/json");
            yield return www.SendWebRequest();
            if (www.isNetworkError || www.isHttpError)
            {
                Debug.LogError(www.error);
            }
            else
            {
                ConfigurationValues = JsonUtility.FromJson<JsonConfig>(www.downloadHandler.text);
                ConfigurationScriptableObject.JsonValues = ConfigurationValues;
                SceneManager.LoadScene("Menu");
            }
        }

    }
}
