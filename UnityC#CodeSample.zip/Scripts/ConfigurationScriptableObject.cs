﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "Data", menuName = "Create Configuration", order = 1)]
public class ConfigurationScriptableObject : ScriptableObject
{
    public GameControls.JsonConfig JsonValues;
    public Sprite[] CardsSprites;
}
