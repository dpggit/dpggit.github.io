﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace GameControls
{
    public class MenuManager : MonoBehaviour
    {
        public void StartButton()
        {
            SceneManager.LoadScene("Game");
        }

        public void ScoreBoardButton()
        {
            SceneManager.LoadScene("ScoreBoard");
        }

        public void ExitButton()
        {
            #if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
            #else
                Application.Quit();
            #endif
        }
    }
}
