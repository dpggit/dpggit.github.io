﻿using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

public class PutJsonTest : MonoBehaviour {

    [System.Serializable]
    public class JsonPut
    {
        public int cardOneId;
        public int cardTwoId;
        public JsonPut(int cardoneid, int cardtwoid)
        {
            this.cardOneId = cardoneid;
            this.cardTwoId = cardtwoid;
        }
    }

    [System.Serializable]
    public class JsonGet
    {
        public bool isCorrect;
    }

    [UnityTest]
    public IEnumerator CheckInServerIfCardsAreCorrect()
    {
        //Set two values we know are a match to test if server gives us its a match
        JsonPut putValues = new JsonPut(7, 7);
        UnityWebRequest www = UnityWebRequest.Put("http://localhost:3000/play/", JsonUtility.ToJson(putValues));
        www.SetRequestHeader("Content-Type", "application/json");
        yield return www.SendWebRequest();
        Assert.IsFalse(www.isNetworkError || www.isHttpError || !JsonUtility.FromJson<JsonGet>(www.downloadHandler.text).isCorrect);
    }
}
