﻿using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

public class ConfigTest {
    [System.Serializable]
    public class JsonConfig
    {
        public int cardScore;
        public int multiplier;
        public int livesCount;
        public int powerupsCount;
        public int[] cardIds;
    }


    [UnityTest]
    public IEnumerator CheckIfCanGetConfigurationDataFromServer()
    {
        UnityWebRequest www = UnityWebRequest.Get("http://localhost:3000/configuration/1");
        www.SetRequestHeader("Accept", "application/json");
        yield return www.SendWebRequest();
        JsonConfig jsonConfig = JsonUtility.FromJson<JsonConfig>(www.downloadHandler.text);
        //Needs to be false all these conditions. Check if there is connection errors, if json is not empty and if cardsids have an even number
        Assert.IsFalse(www.isNetworkError || www.isHttpError || www.downloadHandler.text=="" || jsonConfig.cardIds.Length%2 != 0);
       // yield return CheckIfHasPlayers();
    }


}
