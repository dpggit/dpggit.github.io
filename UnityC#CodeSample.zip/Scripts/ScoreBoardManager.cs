﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace GameControls
{
    [System.Serializable]
    public class ScoreBoardData
    {
        public string ScoreBoardPlayerName;
        public int ScoreBoardValue;
        public ScoreBoardData(string scoreBoardPlayerName, int scoreBoardValue)
        {
            this.ScoreBoardPlayerName = scoreBoardPlayerName;
            this.ScoreBoardValue = scoreBoardValue;
        }
    }

    public class ScoreBoardManager : MonoBehaviour
    {
        public static void SaveScoreBoardData(List<ScoreBoardData> listScoreBoardData)
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/ScoreBoardData.dat", FileMode.OpenOrCreate);
            bf.Serialize(file, listScoreBoardData);
            file.Close();
        }

        public static List<ScoreBoardData> LoadScoreBoardData()
        {
            if (File.Exists(Application.persistentDataPath + "/ScoreBoardData.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Application.persistentDataPath + "/ScoreBoardData.dat", FileMode.Open);
                if (file.Length > 0)
                {
                    List<ScoreBoardData> ScoreBoardList = bf.Deserialize(file) as List<ScoreBoardData>;
                    file.Close();
                    return ScoreBoardList;
                }
                else
                {
                    file.Close();
                    return CreateNewScoreBoardList();
                }
            }
            else return CreateNewScoreBoardList();
        }

        private static List<ScoreBoardData> CreateNewScoreBoardList()
        {
            List<ScoreBoardData> ScoreBoardList = new List<ScoreBoardData>();
            for (int i = 0; i < 5; i++)
            {
                ScoreBoardList.Add(new ScoreBoardData("Player", 0));
            }
            return ScoreBoardList;
        }
    }
}
