﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace GameControls
{
    [System.Serializable]
    public class ScoreBoardTexts
    {
        public Text ScoreBoardPlayerNameTexts;
        public Text ScoreBoardScoreTexts;
    }

    public class GameScoreBoard : MonoBehaviour {

        public ScoreBoardTexts[] ScoreBoardTexts;

        private List<ScoreBoardData> scoreBoardDataList;

        void Start() {
            scoreBoardDataList = ScoreBoardManager.LoadScoreBoardData();
            if(scoreBoardDataList!=null)
            {
                for (int i = 0; i < scoreBoardDataList.Count; i++)
                {
                    ScoreBoardTexts[i].ScoreBoardScoreTexts.text = scoreBoardDataList[i].ScoreBoardValue.ToString();
                    ScoreBoardTexts[i].ScoreBoardPlayerNameTexts.text = scoreBoardDataList[i].ScoreBoardPlayerName;
                }
            }
        }

        public void ButtonMenu()
        {
            SceneManager.LoadScene("Menu");
        }
    }
}
