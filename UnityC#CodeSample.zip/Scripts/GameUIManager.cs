﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace GameControls
{
    public class GameUIManager : MonoBehaviour
    {
        public Text LivesText;
        public Text ScoreText;
        public Text PowerUpsText;
        public Text PlayerNameText;
        public Text MultiplierText;
        public Button PowerUpButton;
        public Transform CardsContainer;
    }
}
