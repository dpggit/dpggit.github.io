﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using System.Linq;

namespace GameControls
{
    [System.Serializable]
    public class JsonPut
    {
        public int cardOneId;
        public int cardTwoId;
        public JsonPut(int cardoneid, int cardtwoid)
        {
            this.cardOneId = cardoneid;
            this.cardTwoId = cardtwoid;
        }
    }

    [System.Serializable]
    public class JsonGet
    {
        public bool isCorrect;
    }

    [System.Serializable]
    public class Players
    {
        public string PlayerName;
        public Color CardsColor;
        public int Score;
        public int Lives;
        public int PowerUps;
        public int PlayerMultiplier;
        public int NumberOfPairsDiscovered;
        public int NumberOfCardsClicksDone;
        public int NumberOfAllowedCardClicks=2;
        public int NumberOfCardsDiscovered;
        public List<GameObject> PlayerCards;
        public GameObject GamePanel;
    }

    public class GameScoreBoardStructure
    {
        public int Score;
        public string PlayerName;
        public GameScoreBoardStructure(int score, string playername)
        {
            this.Score = score;
            this.PlayerName = playername;
        }
    }

    class CardsSelectedInTurn
    {
        public int CardValue;
        public GameObject CardObject;
        public CardsSelectedInTurn(int cardValue, GameObject cardObject)
        {
            this.CardValue = cardValue;
            this.CardObject = cardObject;
        }
    }

    public class GameManager : MonoBehaviour
    {
        public GameObject LoadingAnimation;
        public GameObject CardsPrefab;
        public GameObject GamePanelPrefab;
        public Transform CanvasTransform;
        public Players[] Players;
        public Text WinOrLoseText;
        public string WinMessage;
        public string LoseMessage;
        public int WaitForRestart=5;

        private GameObject cardGameObject;
        private int lastCardId = -1;
        private int finalSpriteId;
        private int actualPlayerTurn;
        private GameObject actualSelectedObject;
        private GameObject lastSelectedObject;
        private JsonConfig jsonConfigValues;
        private Players playerValue;
        private bool gameEnded;
        private Sprite DefaultCardSprite;
        private List<CardsSelectedInTurn> CardsSelectedInTurnList = new List<CardsSelectedInTurn>();

        void Start()
        {
            jsonConfigValues = Configuration.Singleton.ConfigurationScriptableObject.JsonValues;
            //Spawn the game boards for players
            for (int i = 0; i < Players.Length; i++)
            {
                playerValue = Players[i];
                playerValue.Lives = jsonConfigValues.livesCount;
                playerValue.PlayerMultiplier = 1;
                playerValue.NumberOfAllowedCardClicks = 2;
                playerValue.PowerUps = jsonConfigValues.powerupsCount;
                playerValue.GamePanel = Instantiate(GamePanelPrefab);
                playerValue.GamePanel.name = "Panel_Player_" + playerValue.PlayerName;
                playerValue.GamePanel.transform.SetParent(CanvasTransform);
                playerValue.GamePanel.transform.localPosition = Vector3.zero;
                playerValue.GamePanel.GetComponent<GameUIManager>().LivesText.text = playerValue.Lives.ToString();
                playerValue.GamePanel.GetComponent<GameUIManager>().PowerUpsText.text = playerValue.PowerUps.ToString();
                playerValue.GamePanel.GetComponent<GameUIManager>().PlayerNameText.text = playerValue.PlayerName;
                playerValue.GamePanel.GetComponent<GameUIManager>().PowerUpButton.onClick.AddListener(delegate { ActivatePowerUp(); });
                if (i > 0) Players[i].GamePanel.SetActive(false);
                foreach (int sc in jsonConfigValues.cardIds)
                {
                    cardGameObject = Instantiate(CardsPrefab);
                    cardGameObject.GetComponent<Image>().color = playerValue.CardsColor;
                    cardGameObject.transform.SetParent(playerValue.GamePanel.GetComponent<GameUIManager>().CardsContainer);
                    cardGameObject.GetComponent<Button>().onClick.AddListener(delegate { ShowSprite(sc); });
                    playerValue.PlayerCards.Add(cardGameObject);
                }
            }
            DefaultCardSprite = cardGameObject.GetComponent<Image>().sprite;
            LoadingAnimation.transform.SetAsLastSibling();
            WinOrLoseText.transform.SetAsLastSibling();
        }

        void ActivatePowerUp()
        {
            if(Players[actualPlayerTurn].PowerUps>0)
            {
                Players[actualPlayerTurn].PowerUps--;
                Players[actualPlayerTurn].GamePanel.GetComponent<GameUIManager>().PowerUpsText.text = Players[actualPlayerTurn].PowerUps.ToString();
                Players[actualPlayerTurn].NumberOfAllowedCardClicks++;
            }
        }

        void ShowSprite(int SpriteId)
        {
            if (gameEnded) return;
            finalSpriteId = SpriteId - 1;
            Players[actualPlayerTurn].NumberOfCardsClicksDone++;
            actualSelectedObject = EventSystem.current.currentSelectedGameObject;
            if (finalSpriteId >= 0 && Players[actualPlayerTurn].NumberOfCardsClicksDone <= Players[actualPlayerTurn].NumberOfAllowedCardClicks)
            {
                actualSelectedObject.GetComponent<Image>().color = Color.white;
                actualSelectedObject.GetComponent<Image>().sprite = Configuration.Singleton.ConfigurationScriptableObject.CardsSprites[finalSpriteId];
                //If its the same sprite and it is not clicking in the same card twice
                if (finalSpriteId == lastCardId && lastSelectedObject.GetInstanceID() != actualSelectedObject.GetInstanceID())
                {
                    StartCoroutine(CheckInServerIfCardsAreCorrect(finalSpriteId));
                }
                else if (Players[actualPlayerTurn].NumberOfCardsClicksDone == Players[actualPlayerTurn].NumberOfAllowedCardClicks)
                {
                    StartCoroutine(ChangePlayerTurn());
                }
                //The first card clicked, set it as last selected object
                else
                {
                    lastSelectedObject = actualSelectedObject;
                    CardsSelectedInTurnList.Add(new CardsSelectedInTurn(jsonConfigValues.cardIds[finalSpriteId], actualSelectedObject));
                    lastCardId = finalSpriteId;
                }
            }
            else
            {
                Debug.LogError("Sprite Id has a value of 1 or lower");
            }
        }

        IEnumerator ChangePlayerTurn()
        {
            //Disable buttons so that cannot check any other wile changes player turn
            ChangeButtonsState(false);
            yield return new WaitForSeconds(1f);
            actualSelectedObject.GetComponent<Image>().color = Players[actualPlayerTurn].CardsColor;
            actualSelectedObject.GetComponent<Image>().sprite = DefaultCardSprite;
            //If we used the powerup then flip back the card who was not a match
            foreach (CardsSelectedInTurn cs in CardsSelectedInTurnList)
            {
                cs.CardObject.GetComponent<Image>().color = Players[actualPlayerTurn].CardsColor;
                cs.CardObject.GetComponent<Image>().sprite = DefaultCardSprite;
            }
            CardsSelectedInTurnList.Clear();

            yield return new WaitForSeconds(0.5f);
            playerValue = Players[actualPlayerTurn];
            playerValue.Lives--;
            if (playerValue.Lives == 0)
            {
                gameEnded = true;
                CheckScoreBoardValues();
                WinOrLoseText.gameObject.SetActive(true);
                WinOrLoseText.text = LoseMessage + "\nYOU HAVE GOT " + Players[actualPlayerTurn].Score.ToString() + " POINTS";
            }
            else
            {
                playerValue.NumberOfPairsDiscovered = 0;
                playerValue.NumberOfCardsClicksDone = 0;
                playerValue.NumberOfAllowedCardClicks = 2;
                playerValue.PlayerMultiplier = 1;
                playerValue.GamePanel.GetComponent<GameUIManager>().MultiplierText.text = Players[actualPlayerTurn].PlayerMultiplier.ToString();
                playerValue.GamePanel.SetActive(false);
                actualPlayerTurn++;
                if (actualPlayerTurn >= Players.Length) actualPlayerTurn = 0;
                Players[actualPlayerTurn].GamePanel.SetActive(true);
                lastCardId = -1;
                ChangeButtonsState(true);
            }
            playerValue.GamePanel.GetComponent<GameUIManager>().LivesText.text = playerValue.Lives.ToString();
        }

        private void ChangeButtonsState(bool isInteractable)
        {
            foreach (Button b in Players[actualPlayerTurn].GamePanel.GetComponentsInChildren<Button>())
            {
                b.interactable = isInteractable;
            }
        }

        public void RestartGame()
        {
            SceneManager.LoadScene("Game");
        }

        public void MainMenu()
        {
            SceneManager.LoadScene("Menu");
        }

        void CheckScoreBoardValues()
        {
            List<ScoreBoardData> ScoresList = ScoreBoardManager.LoadScoreBoardData();
            foreach (Players p in Players)
            {
                ScoresList.Add(new ScoreBoardData(p.PlayerName, p.Score));
            }
            ScoresList = ScoresList.OrderByDescending(p=>p.ScoreBoardValue).ToList();
            foreach (Players p in Players)
            {
                ScoresList.RemoveAt(ScoresList.Count-1);
            }
            ScoreBoardManager.SaveScoreBoardData(ScoresList);
        }

        IEnumerator CheckInServerIfCardsAreCorrect(int finalSpriteId)
        {
            //Values will be the same but check in server if are the same
            JsonPut putValues = new JsonPut(finalSpriteId, lastCardId);
            UnityWebRequest www = UnityWebRequest.Put("http://localhost:3000/play/", JsonUtility.ToJson(putValues));
            www.SetRequestHeader("Content-Type", "application/json");
            LoadingAnimation.SetActive(true);
            //Disable buttons while is waiting
            ChangeButtonsState(false);
            yield return www.SendWebRequest();
            if (www.isNetworkError || www.isHttpError)
            {
                Debug.LogError(www.error);
            }
            else
            {
                if (JsonUtility.FromJson<JsonGet>(www.downloadHandler.text).isCorrect)
                {
                    LoadingAnimation.SetActive(false);
                    lastCardId = -1;
                    Players[actualPlayerTurn].NumberOfAllowedCardClicks = 2;
                    Players[actualPlayerTurn].NumberOfPairsDiscovered++;
                    Players[actualPlayerTurn].NumberOfCardsDiscovered += 2;
                    Players[actualPlayerTurn].NumberOfCardsClicksDone = 0;
                    Players[actualPlayerTurn].Score += jsonConfigValues.cardScore * 2 * Players[actualPlayerTurn].PlayerMultiplier;
                    Players[actualPlayerTurn].PlayerMultiplier = jsonConfigValues.multiplier * Players[actualPlayerTurn].NumberOfPairsDiscovered;
                    Players[actualPlayerTurn].GamePanel.GetComponent<GameUIManager>().ScoreText.text = Players[actualPlayerTurn].Score.ToString();
                    Players[actualPlayerTurn].GamePanel.GetComponent<GameUIManager>().MultiplierText.text = Players[actualPlayerTurn].PlayerMultiplier.ToString();
                    
                    //If we used the powerup then flip back the card who was not a match
                    if(CardsSelectedInTurnList.Count>1)
                    {
                        foreach (CardsSelectedInTurn cs in CardsSelectedInTurnList)
                        {
                            if (cs.CardValue != jsonConfigValues.cardIds[finalSpriteId])
                            {
                                cs.CardObject.GetComponent<Image>().color = Players[actualPlayerTurn].CardsColor;
                                cs.CardObject.GetComponent<Image>().sprite = DefaultCardSprite;
                                break;
                            }
                        }
                    }
                    CardsSelectedInTurnList.Clear();
                    ChangeButtonsState(true);
                    if (Players[actualPlayerTurn].NumberOfCardsDiscovered == jsonConfigValues.cardIds.Length)
                    {
                        gameEnded = true;
                        CheckScoreBoardValues();
                        WinOrLoseText.gameObject.SetActive(true);
                        WinOrLoseText.text = WinMessage+"\nYOU HAVE GOT "+ Players[actualPlayerTurn].Score.ToString()+" POINTS";
                    }
                }
                else
                {
                    StartCoroutine(ChangePlayerTurn());
                    Debug.LogError("JSON GET from server is not correct");
                }
            }

        }
    }
}
