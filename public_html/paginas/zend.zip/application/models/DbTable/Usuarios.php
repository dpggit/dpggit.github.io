<?php
class Application_Model_DbTable_Usuarios extends Zend_Db_Table_Abstract
{
	protected $_name='usuarios';
	
    public function get($id)  
    {  
        $id = (int) $id;  
        $row = $this->fetchRow('idusu = ' . $id);  
        if (!$row)  
        {  
            throw new Exception("Could not find row $id");  
        }    
        return $row->toArray();  
    }  
	
    public function login($usuario,$pass)  
    {  
        $row = $this->fetchRow("usuario='".mysql_real_escape_string($usuario)."' AND pass='".mysql_real_escape_string($pass)."'");  
        if (!$row)  
        {  
            return false;
        }    
        else return $row->toArray();  
    }  
	
    public function insertar($data)  
    {  
        $this->insert($data);  
    }   
	
	public function actualizar($data)  
    {  
       // $this->update(($data, array('id = ?' => (int) $id);  
    }   

    public function borrar($id)  
    {  
        $this->delete('idusu =' . (int) $id);  
    }   
}
?>