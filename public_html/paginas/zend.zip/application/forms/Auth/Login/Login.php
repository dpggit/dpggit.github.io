<?php
class Default_Form_Auth_Login extends Zend_Form
{
    public function init()
    {
        $this->setMethod('post');
 
        $this->addElement(
            'text', 'nombreusuario', array(
                'label' => 'Usuario:',
                'required' => true,
                'filters'    => array('StringTrim'),
            ));
 
        $this->addElement('password', 'nombrepass', array(
            'label' => 'Contrase�a:',
            'required' => true,
            ));
 
        $this->addElement('submit', 'submit', array(
            'ignore'   => true,
            'label'    => 'Entrar',
            ));
 
    }
}
?>