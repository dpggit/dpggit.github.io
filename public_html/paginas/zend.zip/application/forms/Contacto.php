<?php

class Application_Form_Contacto extends Zend_Form
{

    public function init()
    {
         $this->setName('frmcontacto')
		->setAction("/index/contacto")
		->setEnctype('multipart/form-data')
		->setMethod('post');


		$this->addElement('text', 'nombrecontacto',     
		array(
			'Label' => 'Nombre',
			'style' => 'width:220px',
			'required'   => true,
			'class' => 'inputscontacto',
			)
		);

		$this->addElement('text', 'telefonocontacto',     
		array(
			'Label' => utf8_encode('Tel�fono(*)'),
			'style' => 'width:220px',
			'required'   => true,
			'class' => 'inputscontacto'
			)
		);
		
		$this->addElement('text', 'emailcontacto',     
		array(
			'Label' => utf8_encode('Correo electr�nico(*)'),
			'style' => 'width:220px',
			'required'   => true,
			'class' => 'inputscontacto'
			)
		);
		
		$this->setElementDecorators(
			array(
				array('Label',array('tag' => 'div','style'=>'width:200px')),
				'ViewHelper',
				array('HtmlTag',array('class' => 'divscontacto'))
				)
			);	
    }
}

