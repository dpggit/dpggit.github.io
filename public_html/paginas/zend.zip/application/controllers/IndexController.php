<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
		
		$this->comprobarhora(true);
		
        $loginForm = new Application_Form_Login();
        $this->view->formlogin = $loginForm;
		$loginFiltro = new Application_Form_Filtros();
        $this->view->formfiltros = $loginFiltro;
    }

    public function cambiarFecha($fecha)
    {
		return date("d-m-Y",strtotime($fecha));
    }

    public function ajaxAction()
    {
		$this->comprobarhora(false);
        $this->_helper->layout->disableLayout();  
 		$this->_helper->viewRenderer->setNoRender();
		$tabla = new Application_Model_DbTable_Libros();  
		$rows = $tabla->listar()->toArray();  
		$json = Zend_Json::encode($rows);
		echo $json;  
    }

    public function configuracionAction()
    {
		$loginForm = new Application_Form_Login();
		$this->_helper->layout->disableLayout(); 
		$this->view->valido=false;
		if ($loginForm->isValid($_POST)) 
		{
			$authAdapter = new Zend_Auth_Adapter_DbTable(
				$dbAdapter,
				'usuarios',
				'usuario',
				'pass',
				'MD5(?)');
			
            $authAdapter->setIdentity($loginForm->getValue('nombreusuario'));
            $authAdapter->setCredential($loginForm->getValue('nombrepass'));
 
            $auth   = Zend_Auth::getInstance();
            $result = $auth->authenticate($authAdapter);

            if ($result->isValid()) 
			{
				$nusuario = new Zend_Session_Namespace('valoresusuario');
				$resultados=$authAdapter->getResultRowObject();
				$nusuario->nomusuario = $resultados->usuario;
				$nusuario->idusu = $resultados->idusu;
				//$date = Zend_Date::now();
				$date=strtotime('now');
				$nusuario->hora = $date;
				$nusuario->setExpirationSeconds(600000);
				$this->view->valido=true;
            }
        }
    }

    public function crearimagenAction()
    {
		$this->_helper->layout->disableLayout(); 
    }

    public function getpicsAction()
    {
	
    }

    public function showpicsAction()
    {

    }

    public function iniciarAction()
    {
		$this->_helper->layout->disableLayout(); 
        $formLogin = new Application_Form_Login();
		$this->view->form = $formLogin;
		if ($this->getRequest()->isPost())
		{
			$formData = $this->getRequest()->getPost();
			if ($form->isValid($formData))
			{
				$usuario = $formLogin->getValue('usuario');
				$contrasena = $formLogin->getValue('contrasena');
				$this->_redirect('/');
			}
			else $form->populate($formData);
		}
    }

    public function mostrarfiltrosAction()
    {
        $this->_helper->layout->disableLayout(); 
		$tabla = new Application_Model_DbTable_Anuncios();  
		$this->view->anuncios=$tabla->listar($_POST);
	}

    public function registrarseAction()
    {
        $frmRegistrarse = new Application_Form_Registrarse();
		$this->_helper->layout->disableLayout(); 

		if ($this->getRequest()->isPost())
		{
			$arrusuario=array(
				  'usuario'=>$_POST['nomusuario'],
				  'pass'=>md5($_POST['pass']),
				  'email'=>$_POST['email']
				  );
			
			if ($frmRegistrarse->isValidPartial($arrusuario) && $_SESSION['Zend_Form_Captcha_'.$_POST['captchabid']]['word']==$_POST['captchab'])
			{
				$tabla = new Application_Model_DbTable_Usuarios();  
				$id=$tabla->insert($arrusuario);  
				$nusuario = new Zend_Session_Namespace('valoresusuario');
				$nusuario->nomusuario=$_POST['nomusuario'];
				$nusuario->idusu=$id;
				$date=strtotime('now');
				$nusuario->hora = $date;
				$nusuario->setExpirationSeconds(600000);
			}
			else 
			{
				$this->view->formregistrarse=$frmRegistrarse;
				$frmRegistrarse->populate($_POST);
			}
		}
		else $this->view->formregistrarse=$frmRegistrarse;
    }
    
    
    public function comprobarhora($index)
    {
		if($_SESSION['valoresusuario']['hora'])
		{
			//$date = Zend_Date::now();
			$date=strtotime('now');
			if($date>$_SESSION['valoresusuario']['hora']+600)
			{
				unset($_SESSION['valoresusuario']);
				if(!$index)
				{
				echo 'inactividad';
				die;
				}
			}
			else $_SESSION['valoresusuario']['hora']=$date;
		}
		else if(!$index)
		{
			die;
		}
    }

/*
PARTE DEL CODIGO COMENTADO
*/

}







































