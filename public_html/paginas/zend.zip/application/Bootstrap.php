<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
	protected function _initViewHelpers()
	{
		$this->bootstrap('View');
        $view = $this->getResource('View');
        $view->doctype('XHTML1_STRICT');
		$view->headMeta()->appendHttpEquiv('Content-Type', 'text/html;charset=utf-8');
		$view->headMeta()->appendHttpEquiv('Cache-Control', 'no-cache');
		$view->headTitle()->setSeparator(' - ');
		$view->headTitle('Alquilar');
		$view->headLink()->prependStylesheet("/estilos/estilos.css")."\n"; 	
		$view->headScript()->appendFile("/scripts/jquery.js")."\n";
		Zend_Session::start();
	}
}

