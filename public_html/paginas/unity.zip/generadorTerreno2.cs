/*
Diego Pena Gayo 2013
All rights reserved
Todos los derechos reservados
*/

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class generadorTerreno : MonoBehaviour {
	
	private int numScreenS=0;
	
	private float nivelAgua;
	private GameObject jugador;
	private Vector3 Base;
	private float alturaBaseAgua;
	private float ratioRadio;
	private float ratioRadioMinA;
	private float ratioRadioMinB;
	private float ratioRadioMaxA;
	private float ratioRadioMaxB;
	
	private bool[,] arrLagos;
	private float[,] arrArenas;
	private bool[,] arrBultos;
	private float[,] alturasTerr;
	private float[,] alturasTerrBase;
	private float[,,] splatmapData;
	private int [][,] arrayDetailData;
	private Vector3 TS; // terrain grid-space size
	private Vector2 AS; // control texture size
	private string msgalerta="";
	private int tamBloques = 1;
	private int tamBloquesVeg = 10;
	private Vector3 puffPos=new Vector3(30,0,20);
	private int numale;
	private int numdetailsale;
	private int numtexale;
	private int numradio;
	private int numaleNiveles;
	private int numplantasdif;
	private int numaleFormas;
	private float nummaxalt;

	private int mitadnumradio;
	
	private int densidadMax=100;
	private int densidad=90;
	private int densidadA=98;
	private int densidadT=1;
	
	private Color[] cols;
	private Texture2D texture;
	private int filtro=22;
	private int alturaDetail;
	private int anchuraDetail;
	private bool[,] puntosVeg;
	private float distancia;
	private float anchocamara;
	private float alturacamara;
	private int anchoTerreno;
	private int altoTerreno;
	private Vector3 sizeTerreno;
	private float minCamX;
	private float maxCamX;
	private float minCamY;
	private float maxCamY;
	
	private int minTerrX;
	private int maxTerrX;
	private int minTerrY;
	private int maxTerrY;
	
	private int minDetX;
	private int maxDetX;
	private int minDetY;
	private int maxDetY;
	
	private int[] texBosqueMains;
	private int texBosqueMain;
	private int[] texBosque;
	private int[] texDesierto;
	private int[] texParamo;
	private string[] listaDetalles;
	private string[] listaEstructuras;
	private List<GameObject> objDetalles=new List<GameObject>();

	
	private List<int> arbustos=new List<int>();
	private List<int> arboles=new List<int>();
	private int[] desiertoArb;
	private int[] bosqueArb;
	private int[] paramoArb;
	
	private int anchoExtraTerr=100;
	// Cuanto mas alto mas bajo sera el relieve cuanto mas lejos este del centro, hara cuesta mas pronunciada
	
	private float distanciaB;
	
	private int maxAltura=10;
	private int anchoTotalTerreno;
	private int ratioTotalTerreno=10000;
	
	private float ratioA = 1f/3f;
	private float ratioB = 2f/3f;
	
	private float maximaAltura;

	//astar

	private RaycastHit hitInfo;
	private RaycastHit hit;
	
	private bool[,] arrColsMin;
	private float[,] arrColsBase;
	public float[,] arrCols;
	public float[,] arrColsAng;
	public bool[,] arrOcup;
	//private GameObject[,] arrFog;
	public int arrColsLong;
	//private int arrFogLong;

	public float movimiento=2f;

	//resets
	public bool resetearTodo = false;
	public bool resetearTerreno = false;
	public bool resetearTexturas = false;
	public bool resetearHierbas = false;
	public bool resetearArboleda = false;
	
	//terreno
	public float alturaBase=0.1f;
	// mas alto pendientes mas montañosas
	public float inclinacionTerreno = 0.03f;
	public int maxPlantasDif=3;
	public int radioTerr=150;
	public int maxRadioHierbas=50;
	public int minRadioHierbas=5;
	public int maxRadioTexturas=50;
	public int minRadioTexturas=5;
	public int maxRadioArboleda=50;
	public int minRadioArboleda=5;
	
	public int ratioTexturas=2;
	//num monticulos
	public int ratioAbrupto=1;
	public int ratioHierbas=2;
	public int ratioArboleda=2;
	public int ratioDetalles=2;
	public int ratioEstructuras=1;
	public int ratioLagos=1;
	public int numLagosMax=5;
	//public int ratioRendondeo=5000;
	
	public float anguloMaximoSubida=70f;
	
	public int tipoTerreno;
	public GameObject Camara;
	public Terrain terreno;
	
	public int limiteSaltos;
	public float distance;
	
	public int minPorcentajeX = 10;
	public int maxPorcentajeX = 10;
	public int minPorcentajeZ = 10;
	public int maxPorcentajeZ = 10;
	
	public bool crearTerrenoBase=false;
	
	public float height;
	
	public GameObject agua;
	
	
	void Start () 
	{
		alturaBaseAgua = agua.transform.position.y;

		ratioRadio = (radioTerr/(float)(terreno.terrainData.heightmapWidth))/2f;
		ratioRadioMinA = ratioA-ratioRadio;
		ratioRadioMinB = ratioA+ratioRadio;
		ratioRadioMaxA = ratioB+ratioRadio;
		ratioRadioMaxB = ratioB-ratioRadio;
		
		texBosque = new int[]{0,1};
		texBosqueMains = new int[]{51};
		listaDetalles = new string[]{"rock_01","rock_03"};
		listaEstructuras = new string[]{"Torre"};
		texBosqueMain = (int)(UnityEngine.Random.Range(0,texBosqueMains.Length));
		
		for(int i=0;i<terreno.terrainData.treePrototypes.Length;i++)
		{
			if(terreno.terrainData.treePrototypes[i].prefab.name.Split("-"[0])[0]=="bush") arbustos.Add(i);
			else arboles.Add(i);
		}

		anchocamara = Camara.camera.pixelWidth;
		alturacamara = Camara.camera.pixelHeight;
		anchoTerreno = terreno.terrainData.alphamapWidth;
		altoTerreno = terreno.terrainData.alphamapHeight;
		sizeTerreno = terreno.terrainData.size;
		anchoTotalTerreno = (int)(sizeTerreno.x * sizeTerreno.z);
		
		ratioTexturas=(int)((ratioTexturas*anchoTotalTerreno)/10000);
		ratioAbrupto=(int)((ratioAbrupto*anchoTotalTerreno)/40000);
		ratioHierbas=(int)((ratioHierbas*anchoTotalTerreno)/30000);
		ratioArboleda=(int)((ratioArboleda*anchoTotalTerreno)/80000);
		ratioDetalles=(int)((ratioDetalles*anchoTotalTerreno)/80000);
		ratioEstructuras=(int)((ratioEstructuras*anchoTotalTerreno)/20000);
		ratioLagos=(int)((ratioLagos*anchoTotalTerreno)/80000);
		
		alturaDetail = terreno.terrainData.detailHeight;
		anchuraDetail = terreno.terrainData.detailWidth;

		Camara.camera.useOcclusionCulling = true;
		maximaAltura = alturaBase * 1.5f;
		nivelAgua = alturaBaseAgua+4f;
				
		iniciar();
	}
	
	public void iniciar()
	{		
		alturasAleatorias();
		arbolAleatorio();
		detalles();
		escanear();
		texturasAleatorias();
		hierbasAleatorias();
		spawnPersonajes();
	}

	
	void spawnPersonajes()
	{
		int xx = -1;
		int zz = -1;
		Vector3 posicionPlayer=Vector3.zero;
		int layerMask = 1 << 10;
		for(float x=0;x<sizeTerreno.x;x+=movimiento)
		{
			xx++;
			zz=-1;
			for(float z=0;z<sizeTerreno.z;z+=movimiento)
			{
				zz++;	
				if(Physics.Raycast (new Vector3(x,1000f,z), new Vector3(0,-1,0), out hit, Mathf.Infinity,layerMask))
				{
					if(Vector3.Angle(Vector3.up , hit.normal)<30f)
					{
						if(!arrOcup[xx,zz] && arrCols[xx,zz]>(alturaBaseAgua+70f) && x>50f && (x<sizeTerreno.x-50f) && z>50f && (z<sizeTerreno.z-50f))
						{
							posicionPlayer = new Vector3(xx*movimiento,0,zz*movimiento);
						}
					}
				}
			}
		}

		jugador = Instantiate(Resources.Load ("golem"),posicionPlayer, Quaternion.identity) as GameObject;

		jugador.GetComponent<movTerreno>().camara = Camara;
		jugador.GetComponent<movTerreno>().Terreno = terreno;
		jugador.GetComponent<movTerreno>().movimiento = movimiento;
		jugador.GetComponent<movTerreno>().arrColsLong = arrColsLong;
		jugador.GetComponent<movTerreno>().arrCols = arrCols;
		jugador.GetComponent<movTerreno>().arrOcup = arrOcup;		
		jugador.GetComponent<movTerreno>().limiteSaltos = limiteSaltos;
		jugador.GetComponent<movTerreno>().distance = distance;
		jugador.GetComponent<movTerreno>().height = height;
		jugador.GetComponent<movTerreno>().minPorcentajeX = minPorcentajeX;
		jugador.GetComponent<movTerreno>().maxPorcentajeX = maxPorcentajeX;		
		jugador.GetComponent<movTerreno>().minPorcentajeZ = minPorcentajeZ;
		jugador.GetComponent<movTerreno>().maxPorcentajeZ = maxPorcentajeZ;
		
		jugador.transform.eulerAngles = new Vector3(jugador.transform.rotation.eulerAngles.x,0,jugador.transform.rotation.eulerAngles.z);
	}

	
	void OnGUI () 
	{
		if(GUI.Button (new Rect (Screen.width-150, 20, 150, 30), "Recargar Terreno"))
		{
			Application.LoadLevel("encuentros");	
		}
	}
	
	void Update () {

	}
	
	void escanear()
	{
		int vx=0;
		int vz=0;
		int xx=-1;
		int zz=-1;
		float incy;
		float incx;
		float mitadMov = movimiento/2;
		float iniciox = (sizeTerreno.x*ratioA)+mitadMov;
		float finx = sizeTerreno.x*ratioB;
		float inicioz = (sizeTerreno.z*ratioA)+mitadMov;
		float finz = sizeTerreno.z*ratioB;
		int layerMask = 1 << 10;
		int layerMaskObstaculos =  1 << 11;
		
		arrColsMin=new bool[terreno.terrainData.alphamapWidth,terreno.terrainData.alphamapHeight];
		for(int x=0;x<terreno.terrainData.alphamapWidth;x++)
		{
			for(int z=0;z<terreno.terrainData.alphamapHeight;z++)
			{
				arrColsMin[x,z]=false;
			}
		}
		
		for(float x=0;x<sizeTerreno.x;x+=movimiento)
		{
			vx++;
			vz=0;
			for(float z=0;z<sizeTerreno.z;z+=movimiento)
			{
				vz++;	
			}
		}
		
		arrColsBase=new float[vx,vz];
		arrCols=new float[vx,vz];
		arrOcup = new bool[vx,vz];
		arrColsAng = new float[vx,vz];
		float angulo=0;
		int ratioSonidoOla=0;
		int ratioSonidoGaviota=0;
		int ratioSonidoOlaMax=6;
		int ratioSonidoGaviotaMax=8;
		float ratioSonido=50;
		
		for(float x=0;x<sizeTerreno.x;x+=movimiento)
		{
			xx++;
			zz=-1;
			for(float z=0;z<sizeTerreno.z;z+=movimiento)
			{
				zz++;
				incy = z/sizeTerreno.z;
				incx = x/sizeTerreno.x;
				
                /*...*/
				
				if(Physics.Raycast (new Vector3(x,1000f,z), new Vector3(0,-1,0), out hit))
				{
					if(hit.collider.gameObject.layer==11)
					{
					arrOcup[xx,zz]=true;
					}
					else arrOcup[xx,zz]=false;
				}
				else arrOcup[xx,zz]=false;
				
				if(Physics.Raycast (new Vector3(x,1000f,z), new Vector3(0,-1,0), out hit, Mathf.Infinity,layerMask))
				{
					arrCols[xx,zz]=hit.point.y;
					arrColsBase[xx,zz]=hit.point.y;
					angulo = Vector3.Angle(Vector3.up , hit.normal);
					arrColsAng[xx,zz]=angulo;
                    /*...*/
				}
			}
		}
		arrColsLong = xx;
	}
	
		
	public void destruirTerreno(Vector3 posTerr)
	{
		int radioDestruc = 4;
		float numradioDoble = radioDestruc*radioDestruc;
		float incTerr=0.005f;
		float angulo;
		int y = WorldToTerrainX(posTerr.z-transform.position.z);
		int x = WorldToTerrainY(posTerr.x-transform.position.x);
		int numTex=0;
		bool detenerDes=false;
		float altura = terreno.terrainData.size.y;
		int valorx;
		int valory;
		int h;
		float alturaT;
		float nuevaAlt;
		float profundidad=0.01f/altura;
		profundidad=1f;
		float mediaProf = profundidad/2f;
		float rango;
		Quaternion rotacion;
		GameObject roca;
		Vector2 origen = new Vector2(radioDestruc-0.5f,radioDestruc-0.5f);
		float inclinacion;
		int posx;
		int posy;
		float posWx;
		float posWy;
		int layerMask = 1 << 10;
		int layerMaskObstaculos = 1 << 11;
		//layerMask = ~layerMask;
		float aleatorio;
		
		nummaxalt=1f;

		int valorxmin = x-radioDestruc;
		int valorzmin = y-radioDestruc;
		if(valorxmin<0) valorxmin=0;
		if(valorzmin<0) valorzmin=0;

		int maxAncho = (radioDestruc*2);
		
		bool[,] arrColsMed=new bool[maxAncho,maxAncho];
		
		alturasTerr = terreno.terrainData.GetHeights(valorxmin, valorzmin, maxAncho, maxAncho);
		/*
		 * ...
		 * ...
		 * ...
		*/
		terreno.terrainData.SetHeights(valorxmin, valorzmin, alturasTerr);
		splatmapData=terreno.terrainData.GetAlphamaps(valorxmin,valorzmin, maxAncho, maxAncho);
		for(int xr=0;xr<maxAncho;xr++)
		{
			for(int yr=0;yr<maxAncho;yr++)
			{
				if(arrColsMin[xr+valorxmin,yr+valorzmin]) continue;
				distancia = (new Vector2(xr,yr)-new Vector2(radioDestruc,radioDestruc)).sqrMagnitude;
				if(distancia<=numradioDoble) 
				{
					/*...*/
				}
			}
		}
		
		terreno.terrainData.SetAlphamaps(valorxmin, valorzmin, splatmapData);
		jugador.GetComponent<movTerreno>().arrCols = arrCols;
		
		if(Physics.Raycast (new Vector3(jugador.transform.position.x,1000f,jugador.transform.position.z), new Vector3(0,-1,0), out hitInfo,Mathf.Infinity,layerMask))
		{
			jugador.GetComponent<movTerreno>().posicion = hitInfo.point;
			jugador.transform.position = hitInfo.point;
		}
	}

	void alturasAleatorias()
	{
		/*...*/
	}
	
	void texturasAleatorias()
	{
		/*...*/
	}
	
	void hierbasAleatorias()
	{
		Vector2 escala = Vector2.Scale(new Vector2(terreno.terrainData.detailWidth,terreno.terrainData.detailHeight),new Vector2(anchoTerreno,altoTerreno));
		puntosVeg = new bool[anchuraDetail,alturaDetail];
		terreno.terrainData.wavingGrassStrength=0.3f;
		terreno.terrainData.wavingGrassAmount=0.3f;
		int numDetails = terreno.terrainData.detailPrototypes.Length;
		arrayDetailData = new int[numDetails][,];
		Color colorHealthy = new Color(255f,188f,25f,255f);
		Color colorDry = new Color(205f,188f,26f,255f);
		int ratioSalto = 10;
		terreno.terrainData.wavingGrassTint=colorDry;
		float rTex;
		int numaleHierbas;
		
		/*
		...
		*/
		 
		for (int n=0; n < numDetails; n++) 
		{
			terreno.terrainData.SetDetailLayer(0, 0, n, arrayDetailData[n]);
		}
		
	}

	
    void arbolAleatorio()
	{
		terreno.terrainData.treeInstances = new TreeInstance[0];

		float valorx;
		float valory;
		if(!resetearTodo && !resetearArboleda)
		{
		for (float y = 0; y < altoTerreno; y++)
		{
			for (float x = 0; x < anchoTerreno; x++)
		    {
				numale = (int)(UnityEngine.Random.Range(1,ratioTotalTerreno));
				if(numale<=ratioArboleda)
				{
					valorx = x/anchoTerreno;
					valory = y/altoTerreno;

					numale = (int)(UnityEngine.Random.Range(0,terreno.terrainData.treePrototypes.Length));
					numale = 1;

					Vector3 posicion = new Vector3(valorx,0,valory);
					Vector3 escala = Vector3.Scale(terreno.terrainData.size, posicion);
					if(Physics.Raycast (new Vector3(escala.x,1000f,escala.z), new Vector3(0,-1,0), out hit))
					{
						if(hit.collider.gameObject.layer==10 && Vector3.Angle(Vector3.up , hit.normal)<60f && hit.point.y>40f)
						{
						numdetailsale = (int)(Mathf.Floor(UnityEngine.Random.Range(0,arboles.Count)));
						numdetailsale=0;
                        /* ... */
						}
					}
				}
			}
		}
		}
    }
	
	
	void detalles()
	{
		float angulo;
		float posx;
		float posy;
		float posicionX;
		float posicionZ; 
		int estructuras=0;
		int numale1;
		int maxancho = Mathf.FloorToInt((sizeTerreno.x*0.7f)/movimiento);
		float incx;
		float incy;
		bool heli = false;
		bool bunker = false;
		bool continuar=true;
		int maxRocasGrandes=3;
		int numRocasGrandes=0;
		int layerMask = 1 << 10 | 1 << 11;
		float tamano;
		
		for (float y = 0; y < altoTerreno; y++)
		{
			for (float x = 0; x < anchoTerreno; x++)
		    {
				incx = x/anchoTerreno;
				incy = y/altoTerreno;
				numale = (int)(UnityEngine.Random.Range(1,ratioTotalTerreno));
				if(numale<ratioDetalles)
				{
					posx = TerrainToWorldX(x);
					posy = TerrainToWorldY(y);
					numale1 = (int)(UnityEngine.Random.Range(0,listaDetalles.Length));
					if(Physics.Raycast (new Vector3(posx,1000f,posy), new Vector3(0,-1,0), out hit, Mathf.Infinity, layerMask))
					{
						continuar=true;
						angulo = Vector3.Angle(Vector3.up , hit.normal);
						if(angulo<20f && angulo>0 && hit.point.y>50f)
						{
							tamano = Mathf.Floor(UnityEngine.Random.Range(60f,200f));
							GameObject detalle = Instantiate(Resources.Load(listaDetalles[numale1])) as GameObject;
							detalle.transform.localScale=new Vector3(tamano,tamano,tamano);
							detalle.transform.position=new Vector3(posx,hit.point.y,posy);
							detalle.rigidbody.freezeRotation=true;
							detalle.rigidbody.isKinematic=true;
							numale = (int)(UnityEngine.Random.Range(0,360f));
							detalle.transform.eulerAngles = new Vector3(270f,numale,0);
							if(continuar) objDetalles.Add(detalle);
						}
					}
				}
			}
		}
		
	}

	public int WorldToTerrainX(float posx)
	{
		return (int)(((posx+0)*anchoTerreno)/sizeTerreno.x);
	}
	
	public int WorldToTerrainY(float posy)
	{
		return (int)(((posy+0)*altoTerreno)/sizeTerreno.z);
	}
	
	public float TerrainToWorldX(float posx)
	{
		return (float)((posx*sizeTerreno.x)/anchoTerreno);
	}
	
	public float TerrainToWorldY(float posy)
	{
		return (float)((posy*sizeTerreno.z)/altoTerreno);
	}
	
	int TerrToDetailX(int posx)
	{
		return (int)(anchuraDetail*posx/anchoTerreno);
	}
	
	int TerrToDetailY(int posy)
	{
		return (int)(alturaDetail*posy/altoTerreno);
	}
	
	int DetailToTerrainX(int posx)
	{
		return (int)(anchoTerreno*posx/anchuraDetail);
	}
	
	float DetailToTerrainY(int posy)
	{
		return (float)(altoTerreno*posy/alturaDetail);
	}
	
	float DetailToWorldX(int posx)
	{
		return (float)(sizeTerreno.x*posx/anchuraDetail);
	}
	
	int DetailToWorldY(int posy)
	{
		return (int)(sizeTerreno.z*posy/alturaDetail);
	}
	
	public float AlphaToWorldY(float posx)
	{
		return (float)((posx*sizeTerreno.x)/anchoTerreno);
	}
	
	public float AlphaToWorldX(float posy)
	{
		return (float)((posy*sizeTerreno.z)/altoTerreno);
	}
	
	
	
	bool in_Array(int valor, int[] arr)
	{
		for(int i=0;i<arr.Length;i++)
		{
			if(arr[i]==valor)
			{
				return true;
			}
		}
		return false;
	}
	
	int min_Array(List<int> arr)
	{
		int lowI=0;
		for(int i=0;i<arr.Count;i++)
		{
			if(lowI==0) lowI = arr[i];
			if(arr[i]<lowI) { lowI = arr[i]; }
		}	
		return lowI;
	}
	int max_Array(List<int> arr)
	{
		int highI=0;
		for(int i=0;i<arr.Count;i++)
		{
			if(highI==0) highI = arr[i];
			if(arr[i]>highI) { highI = arr[i]; }
		}	
		return highI;
	}
	
}



