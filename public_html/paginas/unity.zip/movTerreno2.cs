/*
Diego Pena Gayo 2013
All rights reserved
Todos los derechos reservados
*/
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class movTerreno : MonoBehaviour {
	
	private float siguienteDisparo=0;
	private float intervaloDisparos=0.5f;
	private bool isDisparo=false;
	public List<proyectiles> disparos;
	public List<Vector3> destinoDisparos;
	private float alturaPer;
	private float maximaSubida=1f;
	private bool mouseDcho;
	private int velocidadMov=10;
	private Vector3 puntocaminoB=Vector3.zero;
	private int puntoProgreso;
	private List<cAstar> ret;
	private cAstar destino;
	private string msgalerta;
	private float tiempot=0;
	private float ultTiempo=0;
	private float tiempoIntervalo=0.6f;
	private Vector3 posdestino;
	private bool mouseDrag = false;
	private bool mouseIzdo = false;

	private Vector3 moveDirection;
	
	private float minimumY=-60f;
	private float maximumY=60f;
	private float rotationY=0;
	private float alturaExtra=0;
	private int posicionX;
	private int posicionZ;
	private float gradosSubida;
	RaycastHit hitInfo;
	RaycastHit hit;
	private float valormMaxSubida=300f;
	private generadorTerreno objTerr;
	private int ultPosx=0;
	private int ultPosz=0;
	private int valorAlturaExtra=0;
	private Vector3 dire;
	
	
	public Terrain Terreno;
	public GameObject camara;
	public int sensitivityX = 15;
	public int sensitivityY = 10;
	
	public float distance = 25f;
	public float minDist = 5f;
	public float maxDist = 30f;
	public float height = 20f;
	public float heightDamping = 2f;
	public float rotationDamping = 2f;
	public float gravity=2f;
	public float anguloMaximoSubida=50f;
	
	public float movimiento;
	public int arrColsLong;
	public float[,] arrCols;
	//public float[,] arrColsAng;
	public bool[,] arrOcup;
	
	
	public int minPorcentajeX;
	public int maxPorcentajeX;
	public int minPorcentajeZ;
	public int maxPorcentajeZ;
	
	public AudioClip explosion;
	public AudioClip terremotoClip;
	public AudioClip andarClip;
	public AudioClip fuego;
	
	
	private float minx;
	private float maxx;
	private float minz;
	private float maxz;
	
	private float iniciox;
	private float finx;
	private float inicioz;
	private float finz;
	
	public int limiteSaltos=8000;
	
	public Vector3 posicion;
	
	void Start () 
	{
		disparos = new List<proyectiles>();
		destinoDisparos = new List<Vector3>();
		alturaPer=collider.bounds.size.y;
		maximaSubida=alturaPer*1.5f;
		minx = Terreno.terrainData.size.x*minPorcentajeX/100;
		maxx = Terreno.terrainData.size.x-Terreno.terrainData.size.x*maxPorcentajeX/100;
		minz = Terreno.terrainData.size.z*minPorcentajeZ/100;
		maxz = Terreno.terrainData.size.z-Terreno.terrainData.size.z*maxPorcentajeZ/100;
		
		ultTiempo=Time.realtimeSinceStartup;
		ultPosx=Mathf.FloorToInt(posicion.x/movimiento);
		ultPosz=Mathf.FloorToInt(posicion.z/movimiento);
		
		iniciox = Terreno.terrainData.size.x/3;
		finx = Terreno.terrainData.size.x*2/3;
		inicioz = Terreno.terrainData.size.z/3;
		finz = Terreno.terrainData.size.z*2/3;
		
		posicionX = Mathf.FloorToInt(transform.position.x/movimiento);
		posicionZ = Mathf.FloorToInt(transform.position.z/movimiento);
		
		transform.position = new Vector3(transform.position.x,arrCols[posicionX,posicionZ],transform.position.z);
		posicion = transform.position;
		
		rotationY=-10f;
		Quaternion currentRotation = Quaternion.Euler (0, transform.eulerAngles.y, 0);
		camara.transform.position = posicion;
		camara.transform.position -= currentRotation * Vector3.forward * distance;
		camara.transform.position = new Vector3(camara.transform.position.x, posicion.y+height, camara.transform.position.z);
		camara.transform.LookAt (new Vector3(posicion.x,posicion.y+rotationY,posicion.z));

		GameObject proyectorOp = GameObject.Find("ProjectorOpuesto");
		GameObject sol = GameObject.Find("SolEncuentros");
		proyectorOp.GetComponent<SmoothLookAt>().target = sol.transform;
	}
	
	void moverCamara()
	{
		float distancia = distance;
		float altura=height;
		float hDamping = heightDamping;
		int posx;
		int posy;
		Vector3 direccion = Vector3.forward;
		
		if(Physics.Raycast (new Vector3(camara.transform.position.x,camara.transform.position.y,camara.transform.position.z), new Vector3(0,-1,0), out hitInfo))
		{
			if(hitInfo.collider.gameObject.layer==10 && hitInfo.distance<1F)
			{
				direccion = Vector3.back;
			}
		}
		else direccion = Vector3.back;

		alturaExtra=0;
		float wantedRotationAngle = transform.eulerAngles.y;
		float wantedHeight = posicion.y + altura;
		float currentRotationAngle = camara.transform.eulerAngles.y;
		float currentHeight = camara.transform.position.y;
		currentRotationAngle = Mathf.LerpAngle (currentRotationAngle, wantedRotationAngle, rotationDamping * Time.deltaTime);
		currentHeight = Mathf.Lerp (currentHeight, wantedHeight, hDamping * Time.deltaTime);
		Quaternion currentRotation = Quaternion.Euler (0, currentRotationAngle, 0);
		
		if(mouseDrag) transform.rotation = Quaternion.Euler (transform.rotation.eulerAngles.x, currentRotationAngle, transform.rotation.eulerAngles.z);
		
		camara.transform.position = posicion;
		camara.transform.position -= currentRotation * direccion * distancia;

		camara.transform.position = new Vector3(camara.transform.position.x, currentHeight, camara.transform.position.z);
		camara.transform.LookAt (new Vector3(posicion.x,posicion.y+rotationY,posicion.z));
	}
	
	IEnumerator esperarG()
	{
		audio.clip= terremotoClip;
		audio.Play();

		Terreno.GetComponent<generadorTerreno>().destruirTerreno(transform.position);

		animation.Play("hpunch");

		yield return new WaitForSeconds(0.5f);
		audio.clip= explosion;
		audio.Play();
		animation.Play("idle");
	}
	
	IEnumerator esperarF()
	{
		audio.clip= terremotoClip;
		audio.Play();
		animation.Play("hit");
		GameObject ConoF = GameObject.Find("TornadoHielo");
		ConoF.GetComponent<ParticleRenderer>().enabled=true;
		GameObject LA = GameObject.Find("LuzAzulada");
		LA.GetComponent<Light>().enabled=true;
		
		yield return new WaitForSeconds(20f);
		
		ConoF.GetComponent<ParticleRenderer>().enabled=false;
		LA.GetComponent<Light>().enabled=false;
		animation.Play("idle");
	}
	
	IEnumerator esperarH()
	{
		animation.Play("punch");
		Vector3 posDisparo = transform.TransformPoint(0.3f,0.7f,0.3f);
		GameObject disparo = Instantiate(Resources.Load("BolaEnergia"),posDisparo,Quaternion.identity) as GameObject;
		Ray rayo = camara.camera.ScreenPointToRay(Input.mousePosition);
		Vector3 posRayo;
		float eulerY;
        if (Physics.Raycast(rayo, out hitInfo, Mathf.Infinity))
        {
			disparo.GetComponent<colisionParticulas>().puntoImpacto=hitInfo.point;
			eulerY = transform.rotation.eulerAngles.x;
			transform.LookAt(hitInfo.point);
			transform.rotation = Quaternion.Euler(eulerY,transform.rotation.eulerAngles.y,transform.rotation.eulerAngles.z);
			disparos.Add(new proyectiles(disparo,hitInfo.point));
		}
		else 
		{
			Vector3 destinoDisparo = transform.TransformPoint(Vector3.forward * 10f);
			transform.LookAt(destinoDisparo);
			disparos.Add(new proyectiles(disparo,destinoDisparo));
		}
		isDisparo=true;
				
		yield return new WaitForSeconds(1f);
		
		animation.Play("idle");
	}
	
	void Update () 
	{
		if(disparos.Count>0)
		{
			for(int i=0;i<disparos.Count;i++)
			{
				if(disparos[i].proyectil.transform.position.z==disparos[i].destino.z)
				{
					Destroy(disparos[i].proyectil);
					disparos.Remove(disparos[i]);
				}
				else 
				{
					disparos[i].proyectil.transform.position = Vector3.MoveTowards (disparos[i].proyectil.transform.position, disparos[i].destino, Time.deltaTime*20f);
				}
			}
		}
		
		comprobarRuta();
		int centrox;
		int centroz;
		if(Input.GetKeyUp(KeyCode.Escape)) Application.Quit();
		if(Input.GetKeyUp(KeyCode.Space)) animation.Play("jump");
		if(Input.GetKeyUp(KeyCode.F) && puntocaminoB==Vector3.zero) 
		{
			StartCoroutine(esperarF());
		}
		if(Input.GetKeyUp(KeyCode.G)) 
		{
			StartCoroutine(esperarG());
		}
		if(Input.GetKeyUp(KeyCode.K)) animation.Play("faint");

		if(mouseDrag)
		{
			transform.Rotate(0, Input.GetAxis("Mouse X")* sensitivityX, 0);
			camara.transform.Rotate(0, Input.GetAxis("Mouse X")* sensitivityX, 0);
			rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
			rotationY = Mathf.Clamp (rotationY, minimumY, maximumY);
			moverCamara();
		}
		else if(mouseIzdo)
		{
		    Ray rayo = camara.camera.ScreenPointToRay(Input.mousePosition);
			Vector3 posRayo;
            if (Physics.Raycast(rayo, out hitInfo, Mathf.Infinity))
            {
				ultPosx=Mathf.FloorToInt(hitInfo.point.x/movimiento);
				ultPosz=Mathf.FloorToInt(hitInfo.point.z/movimiento);
				if(hitInfo.collider.gameObject.layer == 13) 
				{
					if(Physics.Raycast (new Vector3(hitInfo.collider.bounds.center.x,20000f,hitInfo.collider.bounds.center.z), new Vector3(0,-1,0), out hit))
					{
						if(hitInfo.point.y<=hit.point.y)
						{
							posRayo = hitInfo.point;
							centrox=Mathf.FloorToInt(posRayo.x/movimiento);
							centroz=Mathf.FloorToInt(posRayo.z/movimiento);
							
							if(arrOcup[centrox,centroz])
							{
								if(!arrOcup[centrox,centroz-3]) posRayo = new Vector3(posRayo.x,posRayo.y,posRayo.z-movimiento*2);
								else if(!arrOcup[centrox,centroz+3]) posRayo = new Vector3(posRayo.x,posRayo.y,posRayo.z+movimiento*2);
								else if(!arrOcup[centrox-3,centroz]) posRayo = new Vector3(posRayo.x-movimiento*2,posRayo.y,posRayo.z);
								else if(!arrOcup[centrox+3,centroz]) posRayo = new Vector3(posRayo.x+movimiento*2,posRayo.y,posRayo.z);
							}
							centrox=Mathf.FloorToInt(posRayo.x/movimiento);
							centroz=Mathf.FloorToInt(posRayo.z/movimiento);

							posdestino = new Vector3(posRayo.x,arrCols[centrox,centroz],posRayo.z);

							astar();
						}
					}
				}
				else if(!arrOcup[ultPosx,ultPosz])
				{
					posdestino = hitInfo.point;
					posdestino.y += alturaPer; 
					astar();
				}
            }
		}
	}
	
	
	void OnGUI () 
	{
		GUI.color=Color.yellow;
		Event e = Event.current;

		if(e.button == 0 && e.isMouse &&  Event.current.type==EventType.MouseUp)
	    {
			mouseIzdo = true;
			mouseDrag = false;
			mouseDcho = false;
	    }
		else if(e.button == 1 && e.isMouse &&  Event.current.type==EventType.MouseDrag)
		{
			mouseDrag = true;
			mouseIzdo = false;
			mouseDcho = false;
		}
		else if(e.button == 1 && e.isMouse &&  Event.current.type==EventType.MouseUp)
		{
			mouseDrag = false;
			mouseIzdo = false;
			mouseDcho = true;
		}
		else if(e.button == 2 && e.isMouse && puntocaminoB==Vector3.zero)
		{
			if(Time.time>siguienteDisparo)
			{
				siguienteDisparo = Time.time + intervaloDisparos;
				StartCoroutine(esperarH());
			}
		}
		else
		{
			mouseDrag = false;
			mouseIzdo = false;
			mouseDcho = false;
		}
	}
	
	void comprobarRuta()
	{
		if(puntocaminoB!=Vector3.zero)
		{
			float valorh=(puntocaminoB-posicion).sqrMagnitude;
	
			if(puntoProgreso>0)
			{
				if(valorh==0)
				{
					if(tiempot>0)
					{
						float tiempot2=Time.realtimeSinceStartup;
						float tiempototal=tiempot2-tiempot;
						tiempot=0;
					}
					puntoProgreso--;
					float nuevaAltura=0;
					puntocaminoB=new Vector3(ret[puntoProgreso].post.x,ret[puntoProgreso].post.y+nuevaAltura,ret[puntoProgreso].post.z);
				}
			}
			else 
			{
				puntocaminoB=ret[puntoProgreso].post;
				if(valorh==0)
				{
					if(tiempot>0)
					{
						float tiempot2=Time.realtimeSinceStartup;
						float tiempototal=tiempot2-tiempot;
						tiempot=0;
					}
					posicion=new Vector3(puntocaminoB.x,puntocaminoB.y,puntocaminoB.z);
					transform.position=posicion;
					puntocaminoB=Vector3.zero;
					animation.Play("idle");
					audio.Stop();
					moverCamara();
				}
			}
			if(puntocaminoB!=Vector3.zero)
			{	
				animation.Play("walk");

				posicion=Vector3.MoveTowards(posicion,new Vector3(puntocaminoB.x,puntocaminoB.y,puntocaminoB.z),Time.deltaTime*velocidadMov);
				transform.position=posicion;

				Quaternion oldRotacion = transform.rotation;
				Vector3 direction = puntocaminoB - posicion;
		   		Quaternion nuevaRotation = Quaternion.LookRotation(direction);
				nuevaRotation.x=0;
				nuevaRotation.z=0;
				transform.rotation=Quaternion.Lerp(oldRotacion,nuevaRotation,Time.deltaTime*1.5F);	

				moverCamara();					
			}
		}
	}
	
	private void astar()
	{
		int r=-1;
		ushort alturaRay=1000;
		int lowInd;
		bool gScoreIsBest;
		float gScore;
		bool nlista=false;
		List<cAstar> openList = new List<cAstar>();
		List<cAstar> closedList = new List<cAstar>();
		ret = new List<cAstar>();
		cAstar curr=new cAstar(0,0);
		cAstar currentNode=new cAstar(0,0);
		
		Vector3 posCurrentNode;

		bool siguiente=false;
		Vector3 n0post=Vector3.zero;
		Vector3 n1post=Vector3.zero;
		Vector3 n2post=Vector3.zero;
		Vector3 n3post=Vector3.zero;
		Vector3 n5post=Vector3.zero;
		Vector3 n6post=Vector3.zero;
		Vector3 n7post=Vector3.zero;
		Vector3 n8post=Vector3.zero;
		
		float tiempoInicio=Time.realtimeSinceStartup;
		float tiempoFin;

		RaycastHit hit2;
		int saltos=0;
		int saltosN=0;

		float difAltura=0;
		List<cAstar> neighbors = new List<cAstar>();
		bool diagonales=true;
		int cx;
		int cz;
		float alturaCurr;
		
		bool[,] arrOcupA = new bool[arrColsLong,arrColsLong];
		
        for (int i = 0; i < arrColsLong; i++)
        {
            for (int j = 0; j < arrColsLong; j++)
			{
				arrOcupA[i,j]=arrOcup[i,j];
			}
		}

		puntocaminoB=Vector3.zero;
		int postdestx = Mathf.FloorToInt(posdestino.x/movimiento);
		int postdestz = Mathf.FloorToInt(posdestino.z/movimiento);
		int indicex;
		int indicez;

		indicex = Mathf.FloorToInt(posicion.x/movimiento);
		indicez = Mathf.FloorToInt(posicion.z/movimiento);
		
		cAstar start=new cAstar(indicex,indicez);
		float valorh = (new Vector2(postdestx,postdestz)-new Vector2(indicex,indicez)).sqrMagnitude;
		start.h=valorh;
		start.f=valorh;
		openList.Add(start);
		
		if(indicex==postdestx && indicez==postdestz) return;
		while(openList.Count!=0)
		{
			saltos++;
			if(saltos>limiteSaltos) 
			{
				animation.Play("idle");
				r=-2;
				break;
			}
			
			lowInd = 0;

			for(int i=0;i<openList.Count;i++)
			{
				if(openList[i].f<openList[lowInd].f) { lowInd = i; }
			}

			currentNode=openList[lowInd];
			alturaCurr = arrCols[currentNode.x,currentNode.z];

			if(currentNode.x==postdestx && currentNode.z==postdestz)
			{
				curr = currentNode;
				while(curr.padre!=null)
				{
					curr.post = new Vector3(curr.x*movimiento,arrCols[curr.x,curr.z], curr.z*movimiento);
					ret.Add(curr);
					curr = curr.padre;
				}
				r=ret.Count-1;
				tiempoFin=Time.realtimeSinceStartup;
				float tiempo=tiempoFin-tiempoInicio;
				break;
			}
			else if(currentNode.x>=0 && currentNode.z>=0)
			{
				openList.Remove(currentNode);
				closedList.Add(currentNode);
				arrOcupA[currentNode.x, currentNode.z]=true;
				currentNode.closed=true;

                /*...*/
				
				if(neighbors.Count>0)
				{
					for(int k=0;k<neighbors.Count;k++)
					{
						/*...*/
					} 
				}
			}
			else
			{
				msgalerta+="---ENTRA R2---";
				r=-2;
				puntoProgreso=-1;
				openList = new List<cAstar>();
				animation.Play("idle");
				break;
			}
		} 
		
		if(r>=0)
		{
			animation.Play("walk");
			puntoProgreso=ret.Count-1;
			puntocaminoB=ret[ret.Count-1].post;
			audio.clip=andarClip;
			audio.Play();
		}
		
		tiempot=Time.realtimeSinceStartup;
	}
	
	void tiempoTotal(string msg)
	{
		float tiempot2=Time.realtimeSinceStartup;
		float total=tiempot2-tiempot;
	}
}




public class cAstar 
{
	public Vector3 post;
	public int x;
	public int z;
	public cAstar padre;
	public float g;
	public float h;
	public float f;
	public bool closed;
	public bool open;
	
	public cAstar(int x, int z)
	{
		this.post=Vector3.zero;
		this.x=x;
		this.z=z;
		this.padre=null;
		this.g=0;
		this.h=0;
		this.f=0;
		this.closed=false;
		this.open=false;
	}
}

public class proyectiles
{
    public GameObject proyectil;
    public Vector3 destino;
	
    public proyectiles(GameObject pg, Vector3 d)
    {
		proyectil = pg;
		destino = d;
    }
}
