/*
Diego Pena Gayo 2013
All rights reserved
Todos los derechos reservados
*/

using UnityEngine;
using System.Collections;

public class crearTerreno : MonoBehaviour {
		
	
	
	private string msgalerta;
	private GameObject terreno1;
	private GameObject terrenoMain;
	
	public float movimiento=2f;

	//resets
	public bool resetearTodo = false;
	public bool resetearTerreno = false;
	public bool resetearTexturas = false;
	public bool resetearHierbas = false;
	public bool resetearArboleda = false;
	
	//terreno
	public float alturaBase=0.02f;
	// mas alto pendientes mas montañosas
	public float inclinacionTerreno = 0.02f;
	public int maxPlantasDif=3;
	public int radioTerr=150;
	public int maxRadioHierbas=50;
	public int minRadioHierbas=5;
	public int maxRadioTexturas=50;
	public int minRadioTexturas=5;
	public int maxRadioArboleda=50;
	public int minRadioArboleda=5;
	
	public int ratioTexturas=2;
	//num monticulos
	public int ratioAbrupto=1;
	public int ratioHierbas=2;
	public int ratioArboleda=2;
	public int ratioDetalles=2;
	public int ratioEstructuras=1;
	public int ratioLagos=1;
	public int numLagosMax=5;
	
	public float anguloMaximoSubida=70f;
	
	public int tipoTerreno=1;
	public GameObject sol;
	public GameObject Camara;
			
	public int limiteSaltos=8000;
	
	public float distance=20f;
	
	public int minPorcentajeX = 10;
	public int maxPorcentajeX = 10;
	public int minPorcentajeZ = 10;
	public int maxPorcentajeZ = 10;
	
	public float height=20f;
	
	public GameObject agua;
	
	public Texture2D cursor;
	
	public Material waterSplash;
	
	
	void Start () 
	{
		Screen.showCursor = false;
		sol.light.intensity=0.5f;
		GameObject orilla = Instantiate(Resources.Load ("Nighttime Simple Water"), new Vector3(1000f,30f,1000f),Quaternion.identity) as GameObject;
		orilla.transform.localScale = new Vector3(70000f,1f,70000f);
		
		TerrainData dataTerreno = Instantiate(Resources.Load ("New Terrain 2"),new Vector3(0,0,0), Quaternion.identity) as TerrainData;
		terreno1 = Terrain.CreateTerrainGameObject(dataTerreno);
		terreno1.AddComponent(typeof(ParticleRenderer));
		terreno1.AddComponent(typeof(ParticleEmitter));
		terreno1.GetComponent<ParticleRenderer>().renderer.material=waterSplash;

		terreno1.layer = 10;
	
		terreno1.GetComponent<Terrain>().treeBillboardDistance = 1000f;

		terreno1.GetComponent<Terrain>().treeCrossFadeLength = 20f;

		terreno1.GetComponent<Terrain>().detailObjectDistance = 3000f;

		terreno1.GetComponent<Terrain>().detailObjectDensity=1f;

		terreno1.GetComponent<Terrain>().treeDistance=3000f;

		terreno1.GetComponent<Terrain>().heightmapPixelError=5f;

		terreno1.GetComponent<Terrain>().heightmapMaximumLOD = 0;

		terreno1.GetComponent<Terrain>().treeMaximumFullLODCount = 20000;
		terreno1.GetComponent<Terrain>().castShadows = true;
		terreno1.GetComponent<Terrain>().terrainData.wavingGrassAmount = 0.9f;
		
		terreno1.AddComponent(typeof(generadorTerreno));
		//resets
		terreno1.GetComponent<generadorTerreno>().movimiento=movimiento;
		
		terreno1.GetComponent<generadorTerreno>().terreno=terreno1.GetComponent<Terrain>();
		
		/*...*/
	
	void OnGUI () 
	{
  	  	Rect pos = new Rect(Input.mousePosition.x,Screen.height - Input.mousePosition.y,cursor.width/3f,cursor.height/3f);
    	GUI.Label(pos,cursor);
	}
	
	
	
}
