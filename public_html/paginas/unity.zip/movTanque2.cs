/*
Diego Pena Gayo 2013
All rights reserved
Todos los derechos reservados
*/

using UnityEngine;
using System.Collections;

public class movTanque : MonoBehaviour {
	
	private Vector3 origen;
	private Vector3 destino;
		private float fireRate = 5f;
	private float nextFire = 0;
	
	private Quaternion rotacionA;
	private Quaternion rotacionB;
	private Quaternion rotacionC;
		
	private string msgalerta;
	private bool izda=false;
	private bool dcha=false;
	private bool adelante=false;
	private bool atras=false;
	private int layerMask = 1 << 10;
	private int layerMaskJugador = 1 << 14;
	private RaycastHit hit;
	private bool cuestaArriba;
	private float modVel;
	private float maxVel;
	private float velActualAdelante=0;
	private float velActualAtras=0;
	private float velActualAdelanteFinal;
	private float velActualAtrasFinal;
	private float ultAngulo;
	
	Vector3 dir;
	Vector3 ultDir;
		
	private float rotationY;
	
	public float sensitivityX=30f;
	public float sensitivityY=15f;
	public float minimumY=0;
	public float maximumY=30f;
	public float velAdelante=100f;
	public float velAtras=15f;
	public Camera camara;
	public float aceleracion=5f;
	
	public float distanciaFrontal=7f;
	
	public AudioClip tankidle;
	public AudioClip tankmov;
	
		
	public GameObject partedcha;
	public GameObject parteizda;
	
	void Start () {
		destino = Vector3.zero;
		layerMaskJugador =  ~layerMaskJugador;
		maxVel = velAdelante*1.2f; 
		GameObject proyectorOp = GameObject.Find("ProjectorOpuesto");
		GameObject sol = GameObject.Find("Sol");
		proyectorOp.GetComponent<SmoothLookAt>().target = sol.transform;
		if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z), new Vector3(0,-1,0), out hit, Mathf.Infinity,layerMaskJugador))
		{	
			transform.position = new Vector3(transform.position.x,hit.point.y,transform.position.z);
		}
		rotacionAdelante();
	}
	
	void OnGUI () 
	{
		//GUI.Label (new Rect (10, 20, 700, 700), "Mensaje="+msgalerta);
	}
	
	void Update () 
	{
		if(Input.GetKeyUp(KeyCode.Escape))
		{
			Application.Quit();
		}
		
		audio.mute=true;
		if(Input.GetKey(KeyCode.LeftArrow))
		{
			audio.mute=false;
			Quaternion rotacionX = Quaternion.Euler(transform.rotation.eulerAngles.x,transform.rotation.eulerAngles.y-Time.deltaTime*sensitivityX,transform.rotation.eulerAngles.z);
			transform.rotation = rotacionX;
			if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z), new Vector3(0,-1,0), out hit, Mathf.Infinity,layerMask))
		    {	
				transform.position = new Vector3(transform.position.x,hit.point.y,transform.position.z);
			}
			if(Input.GetKey(KeyCode.DownArrow)) rotacionAtras();
			else if(Input.GetKey(KeyCode.DownArrow)) rotacionAdelante();
			else rotacionLateral();
		}
		if(Input.GetKey(KeyCode.RightArrow))
		{
			audio.mute=false;
			Quaternion rotacionX = Quaternion.Euler(transform.rotation.eulerAngles.x,transform.rotation.eulerAngles.y+Time.deltaTime*sensitivityX,transform.rotation.eulerAngles.z);
			transform.rotation = rotacionX;
			if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z), new Vector3(0,-1,0), out hit, Mathf.Infinity,layerMask))
		    {	
				transform.position = new Vector3(transform.position.x,hit.point.y,transform.position.z);
			}
			if(Input.GetKey(KeyCode.DownArrow)) rotacionAtras();
			else if(Input.GetKey(KeyCode.DownArrow)) rotacionAdelante();
			else rotacionLateral();
		}
		
		if(destino!=Vector3.zero)
		{
			velActualAdelante=0;
			velActualAtras=0;
		}
		
		if(Input.GetKeyUp(KeyCode.UpArrow))
		{
			destino = transform.TransformPoint(Vector3.forward*(velActualAdelante/100f));
			origen = transform.position;
			audio.mute=true;
		}
		
		if(Input.GetKeyUp(KeyCode.DownArrow))
		{
			destino = transform.TransformPoint(Vector3.back*(velActualAtras/100f));
			origen = transform.position;
			audio.mute=true;
		}
		
		if(Input.GetKey(KeyCode.UpArrow))
		{
			destino=Vector3.zero;
			origen=Vector3.zero;
			audio.mute=false;
			modVel=1f;
			if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z) + (transform.forward * distanciaFrontal), new Vector3(0,-1,0), out hit))
		    {			
				if(hit.point.y>transform.position.y) 
				{
					modVel = 1f-((Vector3.Angle(Vector3.up , hit.normal)/25f));
					velActualAdelante+=(((aceleracion*modVel))*Time.deltaTime);
					if(velActualAdelante>velAdelante) velActualAdelante=velAdelante;
				}
				else 
				{
					modVel = (Vector3.Angle(Vector3.up , hit.normal)/100f);
					velActualAdelante+=((aceleracion+(aceleracion*modVel))*Time.deltaTime);
					if(velActualAdelante>maxVel) velActualAdelante=maxVel;
				}

			}
			
			if(velActualAdelante<0) velActualAdelante=0;
			
			transform.Translate(new Vector3(0, 0, velActualAdelante * Time.deltaTime));
			if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z), new Vector3(0,-1,0), out hit, Mathf.Infinity,layerMask))
		    {	
				transform.position = new Vector3(transform.position.x,hit.point.y,transform.position.z);
			}
			rotacionAdelante();
		}

		if(Input.GetKey(KeyCode.DownArrow))
		{
			destino=Vector3.zero;
			origen=Vector3.zero;
			audio.mute=false;
			modVel=1f;
			if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z) - (transform.forward * distanciaFrontal), new Vector3(0,-1,0), out hit, Mathf.Infinity, layerMask))
		    {
				if(hit.point.y>transform.position.y) 
				{
					modVel = 1f-((Vector3.Angle(Vector3.up , hit.normal)/20f)*-1f);
				}
				else modVel = (Vector3.Angle(Vector3.up , hit.normal)/30f);

			}
			velActualAtras+=((aceleracion+(aceleracion*modVel))*Time.deltaTime);
			if(velActualAtras>velAtras) velActualAtras=velAtras;
			if(velActualAtras<0) velActualAtras=0;
			transform.Translate(new Vector3(0, 0, velActualAtras * Time.deltaTime * -1f));
			rotacionAtras();
		}
		
	}
	
	void rotacionLateral()
	{
		if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z)+transform.forward*distanciaFrontal, new Vector3(0,-1,0), out hit, Mathf.Infinity, layerMask))
	    {
            /*...*/
	    }
	    transform.rotation = Quaternion.Slerp(transform.rotation, rotacionB,Time.deltaTime);
	}
	
	void rotacionAdelante()
	{
		dir = transform.position - ultDir;
		if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z)-transform.right*4f+transform.forward*distanciaFrontal, new Vector3(0,-1,0), out hit, Mathf.Infinity, layerMask))
	    {
            /*...*/
	    }
        /*...*/
		float mediaX = (rotacionA.x+rotacionB.x+rotacionC.x)/3f;
		float mediaY = (rotacionA.y+rotacionB.y+rotacionC.y)/3f;
		float mediaZ = (rotacionA.z+rotacionB.z+rotacionC.z)/3f;
		float mediaW = (rotacionA.w+rotacionB.w+rotacionC.w)/3f;
		Quaternion rotacionF = new Quaternion(mediaX,mediaY,mediaZ,mediaW);
	    transform.rotation = Quaternion.Slerp(transform.rotation, rotacionF,Time.deltaTime);
		ultDir = transform.position;
	}
	
	void rotacionAtras()
	{
		if(Physics.Raycast (new Vector3(transform.position.x,1000f,transform.position.z)-transform.right*2f-transform.forward*distanciaFrontal, new Vector3(0,-1,0), out hit, Mathf.Infinity, layerMask))
	    {
            /*...*/
	    }
        /*...*/
		float mediaX = (rotacionA.x+rotacionB.x+rotacionC.x)/3f;
		float mediaY = (rotacionA.y+rotacionB.y+rotacionC.y)/3f;
		float mediaZ = (rotacionA.z+rotacionB.z+rotacionC.z)/3f;
		float mediaW = (rotacionA.w+rotacionB.w+rotacionC.w)/3f;
		Quaternion rotacionF = new Quaternion(mediaX,mediaY,mediaZ,mediaW);
	    transform.rotation = Quaternion.Slerp(transform.rotation, rotacionF,Time.deltaTime);
		audio.mute=false;
	}
	
}