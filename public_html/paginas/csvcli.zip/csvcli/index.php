#!/usr/bin/php -q
<?php
/*
Creación de una aplicación por comandos cli para ayudar a una compañía a determinar las fechas en las que necesitan pagar los salarios.
Los empleados tienen una retribución mensual fija y una bonificación extra cada mes.
Estos salarios son pagados el último día del mes, a no ser que ese día sea Sábado o Domingo. En ese caso los salarios se pagan antes del Sábado.
El día 15 de cada mos los extras se pagan para el mes anterior, a no ser que ese día sea un fin de semana. En ese caso les pagan el primer miércoles
después del día 15.
El archivo creado será con formato .csv y se al crear uno se comprobará si ya existe uno y si tiene todos los meses procesados, si no es así
por cada mes comprobarán las condiciones anteriormente mencionadas y se guardará en el archivo.
El formato del archivo .csv será mostrar los siguientes doce meses a partir de la fecha actual, poniendo dos filas y tres columnas por cada mes,
una fila para los títulos y otra para los valores, y de las tres columnas una para el nombre del mes, otra para la fecha de pago fija y otra para
la fecha de pago del extra

Para iniciar la aplicación seguir las instrucciones en instrucciones.txt

*/
try
{
	// Que no muestre los errores notice
	error_reporting(7);
	// Quito el primero de los argumentos
	array_shift($argv);
	// Comprobar que se da algun argumento despues de php index.php
	if(!is_null($argv[0])) 
	{
		// Si el primer argumento es help cargar el archivo de instrucciones
		if($argv[0]=="help") echo file_get_contents("instrucciones.txt");
		// Si el primer argumento es start crear el archivo csv
		else if($argv[0]=="start")
		{
			// Se incluye el controlador y se instancia
			require_once("starting.php");
			$o = new starting();
			$change = "Los separadores se han actualizado correctamente".PHP_EOL;
			// Si existe el archivo lo actualiza si hace falta
			if(file_exists($o->nfile))
			{
				// Se hace un array con la segunda línea de valores del documento csv
				// Se comprueba si tiene 36 separaciones, que sería el máximo para un año, 12 meses por 3 separaciones
				$arrtitles = $o->successSave();	
				if(count($arrtitles)==36)
				{
					$arrdatenow = getdate(strtotime("now"));
					$month=$arrdatenow["mon"];
					$arrmonths = $o->months();
					for($i=1;$i<=12;$i++)
					{
						$month++;
						if($month>12) $month=1;
					}
					// Si el mes de la última modificación del archivo es diferente al mes actual entonces actualizar el archivo
					$fechamod = getdate(filemtime($o->nfile));
					if($fechamod['mon']!=$month) $o->start($argv[1]);
					// Si es igual pero hace falta cambiar el tipo de separación de ; a , 
					else if($argv[1]!="," && $o->comma) 
					{
						$contents=str_replace(",",";",file_get_contents($o->nfile));
						file_put_contents($o->nfile,$contents);
						echo $change;
					}
					// Si es igual pero hace falta cambiar el tipo de separación de , a ; 
					else if($argv[1]=="," && !$o->comma) 
					{
						$contents=str_replace(";",",",file_get_contents($o->nfile));
						file_put_contents($o->nfile,$contents);
						echo $change;
					}
					else echo "No son necesarios cambios".PHP_EOL;
				}
			}
			// Si no existe el archivo lo crea
			else 
			{
				if($argv[1]=="") $argv[1]=";";
				$o->start($argv[1]);
			}
		}
		else throw new Exception('Debes especificar el parametro "start" o "help"');
	}
	else throw new Exception('Debes especificar el parametro "start" o "help"');
}
catch (Exception $e)
{  
	if(file_exists($o->nfile)) unlink($o->nfile); 
	echo $e->getMessage();
}
?>
