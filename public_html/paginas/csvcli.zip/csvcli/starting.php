<?php
require_once("baseclass.php");
class starting extends baseclass
{
    function start($separator)
    {
			$columns="";
			$dformat = "d-m-Y";
			$now = strtotime("now");
			$arrdatenow = getdate($now);
			$year = $arrdatenow["year"];
			$month=$arrdatenow["mon"];
			$arrmonths = $this->months();
			$pos=0;
			$fp = fopen($this->nfile, 'w');
			chmod($this->nfile, 0777);
			flock($fp, LOCK_EX);
			for($i=1;$i<=12;$i++)
			{
				$month++;
				$year+=floor(($month-1)/12);
				if($month>12) $month=1;
				$date15th = mktime(0,0,0,$month,15,$year);
				// ¿Es el día 15 del mes fin de semana?
				if($this->isWeek($date15th)) 
				{
					for($d=1;$d<=4;$d++)
					{
						$wed=mktime(0,0,0,$month,15+$d,$year);
						if($this->isWed($wed)) 
						{
							$bonusdate = date($dformat,$wed);
							break;
						}
					}
				}
				else $bonusdate = date($dformat,$date15th);
				// ¿Es el último día del mes fin de semana?
				$lastday=mktime(0,0,0,$month+1,0,$year);
				if($this->isWeek($lastday)) 
				{
					$arrlastday = getdate($lastday);
					if($arrlastday["wday"]==0) $lastday=mktime(0,0,0,$month+1,-2,$year);
					else $lastday=mktime(0,0,0,$month+1,-1,$year);
					$paydate = date($dformat,$lastday);
				}
				else $paydate = date($dformat,$lastday);
				// Si es el primer mes creo los títulos de la primera línea
				if($i==1)
				{
					$m=$month;
					for($j=1;$j<=12;$j++)
					{
						if($j>1) $columns.=$separator;
						if($m>12) $m=1;
						$columns.='"'.$arrmonths[$m-1].'"'.$separator.'"PAGO"'.$separator.'"EXTRA"';
						$m++;
					}
					$columns.=PHP_EOL;
					fwrite($fp, $columns);
					$addsep="";
				}
				else $addsep = $separator;
				// Creo los datos correspondientes al mes para la segunda fila con los valores
				fwrite($fp, $addsep.'""'.$separator.'"'.$paydate.'"'.$separator.'"'.$bonusdate.'"');
			}
			flock($fp, LOCK_UN);
			fclose($fp);
			if(!file_exists($this->nfile)) throw new Exception('El archivo no se ha creado'.PHP_EOL);
			else if(count($this->successSave())==36) echo "Archivo creado correctamente".PHP_EOL;
			else
			{
				throw new Exception("El archivo se intento crear con el número de columnas incorrectas".PHP_EOL);
			}
    }
}
?>
