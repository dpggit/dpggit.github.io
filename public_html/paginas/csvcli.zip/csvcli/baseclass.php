<?php
abstract class baseclass
{
	public $nfile = "outputfile/TheBurroughsTest.csv";
	public $comma = true;
    function months()
    {
		//return array("JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER");
		return array("ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO","JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE");
    }
    function isWeek($timestamp)
    {
		$arrdate = getdate($timestamp);
    	return ($arrdate["wday"]==6 || $arrdate["wday"]==0)?true:false;
    }
    function isWed($timestamp)
    {
		$arrdate = getdate($timestamp);
    	return $arrdate["wday"]==3?true:false;
    }
    // Lee el fichero csv y comprueba que se ha guardado correctamente
    // Se hace un array con los valores del documento csv
    function successSave()
    {
		$fp = fopen($this->nfile, 'r');
			$this->comma=true;
			$arrtitles=array();
			$arrtitles=explode(",",fgets($fp));
			if(count($arrtitles)<=1) 
			{
				$this->comma=false;
				rewind($fp);
				$arrtitles=explode(";",fgets($fp));
			}
		fclose($fp);
		return $arrtitles;
    }
}
?>
