<?php
require_once("cbase/cbase.php");
class m_iniciar extends cbase
{
	// Consulta donde quiero conseguir una lista de hospedajes buscando por el nombre del establecimiento
	// o el nombre del municipio o la provincia
	// Se busca solo por los tres primeros caracteres del valor de la búsqueda
    protected function datos($valor)
    {
    	// Para mayor seguridad limpiar de caracteres potencialmente peligrosos para una consulta a la base de datos
    	$valor = $this->limpiar($valor);
		$sql = "SELECT CONCAT_WS(',',h.nombre,
		IF(h.tipo=1,CONCAT(a.numdisp,' apartamentos'),CONCAT(ho.estrellas,' estrellas')),
		IF(h.tipo=1,CONCAT(a.numadultos,' adultos'),CONCAT('habitación ',t.nombretipo)),
		m.municipio,p.provincia) AS texto
		FROM hospedajes h
		LEFT JOIN apartamentos a ON h.idtipo=idapart
		LEFT JOIN hoteles ho ON h.idtipo=idhotel
		INNER JOIN tipos_habitaciones t ON t.idtipo=ho.tipohab
		INNER JOIN municipios m ON h.ciudad=m.id
		INNER JOIN provincias p ON h.provincia=p.id
		WHERE nombre LIKE '%".mysql_real_escape_string(substr($valor,0,3))."%'
		OR m.municipio LIKE '%".mysql_real_escape_string(substr($valor,0,3))."%'	
		OR p.provincia LIKE '%".mysql_real_escape_string(substr($valor,0,3))."%'	
		COLLATE utf8_bin
		ORDER BY h.nombre
		";
		$valorobjeto=mysql_query($sql);
		$textos = array();
		while($objeto=mysql_fetch_array($valorobjeto))
		{
			array_push($textos,$objeto['texto']);
		}
		if(count($textos)==0) array_push($textos,"No hay resultados");
		return $textos;
    }
}
?>
