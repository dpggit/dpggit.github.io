<?php
ini_set("session.gc_maxlifetime", "18000");
session_cache_limiter('nocache,private');
session_name('test');
session_start();
?>