<?php
class BD
{
	static $instancia;
	// Para evitar ser instanciado se pone private
    private function __construct()
    {
      $this->conectar();
    }
	public static function getInstance()
	{
	  if (  !self::$instancia instanceof self)
	  {
	     self::$instancia = new self;
	  }
	  return self::$instancia;
	}
	public function conectar()
    {
		$con = mysql_connect($_SERVER['host'], "nusuario", "npass"); 
		mysql_select_db("nombrebd", $con); 
		@mysql_query("SET NAMES 'utf8'");
    }
}
BD::getInstance();
?>
