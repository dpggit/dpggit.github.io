<?php
include("modelos/m_iniciar.php");
class c_iniciar extends m_iniciar
{
    function GET($valor)
    {
    	global $variables;
    	// La base de datos me da un array con los resultados de la búsqueda
    	$variables = $this->datos($valor['busqueda']);
    }
}
?>
