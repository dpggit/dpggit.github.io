<?php
/*
Aplicación web para especificar un texto y que la base de datos mysql busque los establecimientos con ese nombre
y muestre los resultados
*/


// Por si quiero hacer un echo despues de mandar los header, no manda nada hasta en ob_end_flush
ob_start();
try
{
	// Pagina de tipo html y con codificación utf8
	header('Content-type: text/html; charset=utf-8');
	// Las consultas seran del tipo nombreservidor/pruebatrabajo/controlador&metodo&valor
	// El valor es opcional
	// por ejemplo /pruebatrabajo/iniciar&get
	$arr = explode('?', $_SERVER['REQUEST_URI']);
	$modarr = explode('&', $arr[1]);
	if($modarr[0]) $controlador = $modarr[0];
	if($modarr[1]) $metodo = $modarr[1];
	if($modarr[2]) $valor = $modarr[2];
	$template = $controlador."_".$metodo;
	if(!isset($_SESSION))
	{
		require_once("config/conexion.php");
		require_once("config/configuracion.php");
	}
	// Incluyo el encabezado con html, body, y head de la vista
	require_once("templates/layout.htm");

	if (file_exists("controladores/c_".$controlador.".php") && $metodo!="") 
	{
		//incluyo el controlador
		require_once("controladores/c_".$controlador.".php");
		$controlador='c_'.$controlador;
		$clase=new $controlador();
		if($valor=='')
		{
			if($_POST) $valor = $_POST;
			else if($_GET) $valor = $_GET;
		}
		// llamo al metodo del controlador que llamará al modelo
		$clase->$metodo($valor);
		// incluyo la vista correspondiente que tendrá el nombre del nombrecontrolador_nombremetodo.htm
		require_once("templates/".$template.".htm");
	}
	else
	{
		// Si no dan el controlador y el metodo cargar la vista de inicio
		require_once("templates/inicio.htm");
	}
}
catch (Exception $e){ echo $e->getMessage();}
echo "</body></html>";
ob_end_flush();

?>
